-- name: GetTask :one
SELECT * FROM `task` WHERE `id`=? LIMIT 1;

-- name: ListUnStartedTasks :many
SELECT * FROM `task` WHERE `status`=0 AND `worker_id`=? ORDER BY `created_at` LIMIT ?;

-- name: CreateTask :execlastid
INSERT INTO `task` (site, root_url, status, rule, worker_id, remark) VALUES (?, ?, ?, ?, ?, ?);

-- name: UpdateTask :execrows
UPDATE `task` SET `status`= ?, `total_crawled`= ?, `duration`= ?  WHERE `id`= ?;


-- name: CreateCrawl :execlastid
INSERT INTO `crawl` (task_id, title, link, udl, remark) VALUES (?, ?, ?, ?, ?);

-- name: GetTotalCrawled :one
SELECT COUNT(*) AS total FROM `crawl` WHERE `task_id`= ?;