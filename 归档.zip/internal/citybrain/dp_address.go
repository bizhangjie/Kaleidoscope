package citybrain

import (
	"bytes"
	"datasystem-discoverer/internal/config"
	"encoding/json"
	"errors"
	"io"
	"log"
	"net/http"
	"strconv"
	"sync/atomic"
	"time"

	"github.com/tidwall/gjson"
)

type AddressCreator struct {
	tokenUpdateAt time.Time
	httpClient    *http.Client
	token         atomic.Value
	tokenApi      string
	addressApi    string
	accountInfo   map[string]string
}

// refreshToken 刷新token
func (c *AddressCreator) refreshToken() error {
	log.Println("[AddressCreator-info]Start refreshToken")

	payload, _ := json.Marshal(c.accountInfo)

	resp, err := c.httpClient.Post(c.tokenApi, "application/json", bytes.NewReader(payload))
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return errors.New("http status:" + strconv.Itoa(resp.StatusCode))
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	token := gjson.GetBytes(body, "data.access_token").String()
	if token == "" {
		return errors.New("refresh token failed")
	}

	log.Printf("[AddressCreator-info]RefreshToken success: %s", token)

	c.token.Store(token)

	return nil
}

// NewAddressCreator 创建地址上报
func NewAddressCreator(cfg config.Address) *AddressCreator {
	client := &http.Client{}

	c := &AddressCreator{
		tokenUpdateAt: time.Time{},
		httpClient:    client,
		tokenApi:      cfg.TokenAPI,
		addressApi:    cfg.AddressAPI,
		accountInfo: map[string]string{
			"client_id":  cfg.ClientID,
			"username":   cfg.Username,
			"password":   cfg.Password,
			"grant_type": "password",
		},
	}

	err := c.refreshToken()
	if err != nil {
		log.Println(err)
	}

	// 定时刷新token
	go func() {
		ticker := time.NewTicker(10 * time.Minute)

		log.Println("[AddressCreator]Start ticker to refresh token")
		for range ticker.C {
			err := c.refreshToken()
			if err != nil {
				log.Println(err)
			}
		}
	}()

	return c
}

// Create 生成DPAddress
func (c *AddressCreator) Create(name, description, link, sourceTitle, sourceLink string, permission int) (string, error) {
	payload := map[string]any{
		"name":             name,
		"desc":             description,
		"in_yun_qi":        2,
		"hyper_link":       link,
		"permission":       permission,
		"source_link_info": []map[string]string{{"name": sourceTitle, "source_link": sourceLink}},
	}

	b, err := json.Marshal(payload)
	if err != nil {
		return "", err
	}

	req, err := http.NewRequest("POST", c.addressApi, bytes.NewReader(b))
	if err != nil {
		return "", nil
	}

	req.Header.Set("Authorization", "Bearer "+c.token.Load().(string))
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	if resp.StatusCode != http.StatusOK {
		return "", errors.New("create DPAddress failed, code:" + strconv.Itoa(resp.StatusCode))
	}

	dpAddress := gjson.GetBytes(data, "data.dp_address").String()

	return dpAddress, nil
}
