package http

import (
	"github.com/gin-gonic/gin"
)

// jsonResp http响应内容标准json结构
func jsonResp(code int, message string, data interface{}) gin.H {
	return gin.H{
		"code":    code,
		"message": message,
		"data":    data,
	}
}
