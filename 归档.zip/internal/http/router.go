package http

import (
	"datasystem-discoverer/internal/crawler"
	"net/http"

	"github.com/gin-contrib/pprof"
	"github.com/gin-gonic/gin"
)

const authorizationToken = "yqgcy2050!!"

var r *gin.Engine

// InitRouter 初始化http路由
func InitRouter(crawler *crawler.Crawler) *gin.Engine {
	gin.SetMode(gin.ReleaseMode)
	r = gin.Default()

	pprof.Register(r)

	mux := NewMux(crawler)

	r.Use(func(ctx *gin.Context) {
		if ctx.GetHeader("Authorization") != authorizationToken {
			ctx.JSON(http.StatusForbidden, jsonResp(http.StatusForbidden, "not authorized", nil))
			ctx.Abort()
		}
	})

	r.POST("/submit", mux.submit)
	r.POST("/fetch", mux.fetch)
	r.POST("/cleanup", mux.cleanUp)
	r.GET("/task/:taskId", mux.taskDetail)

	return r
}
