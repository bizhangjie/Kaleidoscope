package http

import (
	"datasystem-discoverer/internal/crawler"
	"datasystem-discoverer/pkg/logger"
	"datasystem-discoverer/pkg/parser"
	"github.com/gin-gonic/gin"
	"net/http"
)

type Mux struct {
	cr     *crawler.Crawler
	logger logger.Logger
}

func NewMux(cr *crawler.Crawler) *Mux {
	return &Mux{
		cr:     cr,
		logger: logger.NewStdLogger("[HTTP]"),
	}
}

// fetch 执行抓取任务
func (m *Mux) fetch(c *gin.Context) {
	// 解析post规则列表
	var rules []parser.Rule
	err := c.ShouldBindJSON(&rules)
	if err != nil {
		c.JSON(http.StatusBadRequest, jsonResp(http.StatusBadRequest, err.Error(), nil))
		return
	}

	// 创建爬取任务
	task, err := m.cr.CreateTask(rules, true)
	if err != nil {
		m.logger.Error("fetch CreateTask", err)
		c.JSON(http.StatusInternalServerError, jsonResp(http.StatusInternalServerError, err.Error(), nil))
		return
	}

	// 执行爬取任务
	err = m.cr.ExecTask(task)
	if err != nil {
		c.JSON(http.StatusInternalServerError, jsonResp(http.StatusInternalServerError, err.Error(), nil))
		return
	}

	c.JSON(http.StatusOK, jsonResp(http.StatusOK, "", *task))
	return
}

// submit 提交抓取任务，开始执行时间不确定
func (m *Mux) submit(c *gin.Context) {
	// 解析post规则列表
	var rules []parser.Rule
	err := c.ShouldBindJSON(&rules)
	if err != nil {
		c.JSON(http.StatusBadRequest, jsonResp(http.StatusBadRequest, err.Error(), nil))
		return
	}

	// 创建爬取任务
	task, err := m.cr.CreateTask(rules, false)
	if err != nil {
		m.logger.Error("submit CreateTask", err)
		c.JSON(http.StatusInternalServerError, jsonResp(http.StatusInternalServerError, err.Error(), nil))
		return
	}

	c.JSON(http.StatusOK, jsonResp(http.StatusOK, "", *task))
	return
}

// taskDetail 查询任务详情
func (m *Mux) taskDetail(c *gin.Context) {
	taskId := c.Param("taskId")
	task, err := m.cr.GetTaskDetail(taskId)
	if err != nil {
		c.JSON(http.StatusInternalServerError, jsonResp(http.StatusInternalServerError, err.Error(), nil))
		return
	}

	c.JSON(http.StatusOK, jsonResp(http.StatusOK, "", *task))
	return
}

// cleanUp 清理历史任务
func (m *Mux) cleanUp(c *gin.Context) {
	c.JSON(http.StatusOK, jsonResp(http.StatusOK, "needs to implement", nil))
}
