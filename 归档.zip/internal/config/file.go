package config

import (
	"io"
	"log"
	"os"

	"gopkg.in/yaml.v3"
)

func FromFile() AppConfig {
	var cfg AppConfig

	f, err := os.Open("config.yaml")
	if err != nil {
		log.Fatalln(err)
	}
	defer f.Close()

	content, err := io.ReadAll(f)
	if err != nil {
		log.Fatalln(err)
	}

	err = yaml.Unmarshal(content, &cfg)
	if err != nil {
		log.Fatalln(err)
	}

	return cfg
}
