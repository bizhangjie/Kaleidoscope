package config

type Address struct {
	TokenAPI   string `yaml:"tokenApi"`
	AddressAPI string `yaml:"addressApi"`
	ClientID   string `yaml:"clientId"`
	Username   string `yaml:"username"`
	Password   string `yaml:"password"`
}

type AppConfig struct {
	TestMode           bool    `yaml:"testMode"`
	HTTPListenAt       string  `yaml:"httpListenAt"`
	ChromeDebugURL     string  `yaml:"chromeDebugUrl"`
	MaxTaskConcurrent  int     `yaml:"maxTaskConcurrent"`
	DbConnectionString string  `yaml:"dbConnectionString"`
	WorkerID           string  `yaml:"workerId"`
	Address            Address `yaml:"address"`
}
