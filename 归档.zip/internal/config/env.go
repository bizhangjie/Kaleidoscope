package config

import (
	"log"
	"os"
	"strconv"
)

func FromEnv() AppConfig {
	workerId := getEnvString("WORKER_ID", "")
	if workerId == "" {
		log.Fatalln("WORKER_ID not set")
	}

	return AppConfig{
		TestMode:     getEnvBool("TEST_MODE", true),
		HTTPListenAt: getEnvString("LISTEN_AT", ":8081"),
		// 未设置HEADLESS_CHROME_HOST环境变量，则为docker run运行方式，且headless-chrome跑在宿主机
		// 设置HEADLESS_CHROME_HOST环境变量，则为docker compose运行方式，该环境变量设置为headless-chrome的service name
		ChromeDebugURL:     getEnvString("HEADLESS_CHROME_URL", "ws://host.docker.internal/9222"),
		MaxTaskConcurrent:  getEnvInt("MAX_TASK_CONCURRENT", 1),
		DbConnectionString: getEnvString("DB_CONNECTION_STRING", ""),
		WorkerID:           workerId,
		Address: Address{
			TokenAPI:   getEnvString("ADDRESS_TOKEN_API", ""),
			AddressAPI: getEnvString("ADDRESS_ADDRESS_API", ""),
			ClientID:   getEnvString("ADDRESS_CLIENT_ID", ""),
			Username:   getEnvString("ADDRESS_USERNAME", ""),
			Password:   getEnvString("ADDRESS_PASSWORD", ""),
		},
	}
}

func getEnvBool(envName string, defaultValue bool) bool {
	value := os.Getenv(envName)
	if value == "" {
		return defaultValue
	}

	v, _ := strconv.ParseBool(value)
	return v
}

func getEnvString(envName, defaultValue string) string {
	value := os.Getenv(envName)
	if value == "" {
		return defaultValue
	}

	return value
}

func getEnvInt(envName string, defaultValue int) int {
	value := os.Getenv(envName)
	if value == "" {
		return defaultValue
	}

	v, _ := strconv.Atoi(value)
	return v
}
