package crawler

import (
	"context"
	"datasystem-discoverer/internal/config"
	"datasystem-discoverer/pkg/fetcher"
	"datasystem-discoverer/pkg/logger"
	"datasystem-discoverer/pkg/parser"
	"datasystem-discoverer/pkg/store"
	"datasystem-discoverer/pkg/util"
	"errors"
	"strconv"
	"sync"
	"time"
)

type Crawler struct {
	maxTaskConcurrent int
	httpFetcher       fetcher.HttpFetcher
	chromeFetcher     fetcher.ChromeFetcher
	logger            logger.Logger
	store             store.Store
	stopChan          chan struct{}
}

func New(cfg config.AppConfig) *Crawler {
	var s store.Store

	if cfg.TestMode { // 测试模式，不注册DPAddress
		s = store.NewMysqlForTestStore(context.Background(), cfg)
	} else {
		s = store.NewMysqlStore(context.Background(), cfg)
	}

	return &Crawler{
		maxTaskConcurrent: cfg.MaxTaskConcurrent,
		httpFetcher:       fetcher.NewHttpFetcher(15*time.Second, ""),
		chromeFetcher:     fetcher.NewChromeFetcher(cfg.ChromeDebugURL, false, 30*time.Second),
		logger:            logger.NewStdLogger("Crawler"),
		store:             s,
		stopChan:          make(chan struct{}, 1),
	}
}

// CreateTask 创建爬取任务
func (c *Crawler) CreateTask(rules []parser.Rule, manualExec bool) (*store.Task, error) {
	status := store.TaskStatusUnStart
	if manualExec {
		status = store.TaskStatusStarted
	}
	task, err := c.store.CreateTask(rules, status, "")
	if err != nil {
		c.logger.Error("CreateTask", err)
		return nil, err
	}
	c.logger.Info("CreateTask", task.TaskId)

	return task, nil
}

// ExecTask 执行爬取任务
func (c *Crawler) ExecTask(task *store.Task) error {
	if task == nil || len(task.Rules) == 0 || task.Rules[0].RequestUrl == "" {
		c.logger.Info("fetch invalid task", task.TaskId)
		c.store.UpdateTask(task.TaskId, store.TaskStatusFailed, 0)
		return errors.New("invalid task")
	}

	c.logger.Info("ExecTask", task.Rules[0].RequestUrl)

	// 记录开始时间
	timeStart := time.Now()

	// 递归并发爬取
	c.walk(task, 0, task.Rules[0].RequestUrl, task.Rules[0].Name)

	// 抓取完成共花费时间/毫秒
	duration := time.Since(timeStart).Milliseconds()

	c.store.UpdateTask(task.TaskId, store.TaskStatusSuccess, int(duration))

	return nil
}

// request 对URL发起请求
func (c *Crawler) request(requestUrl string, rule parser.Rule) ([]byte, error) {
	var content []byte
	if rule.Type == parser.ParseTypeChrome {
		c.logger.Info("ChromeFetcher", "Started")
		resp, err := c.chromeFetcher.PaginateFetch(requestUrl, rule)
		c.logger.Info("ChromeFetcher", "Finish")
		if err != nil {
			c.logger.Error("walk chromeFetcher fetch", err)
			return nil, err
		}

		content = util.StringToBytes(resp)
	} else {
		// http请求，获取资源内容
		resp, err := c.httpFetcher.Get(requestUrl)
		if err != nil {
			c.logger.Error("walk fetcher.Get", err)
			return nil, err
		}

		content = resp
	}

	return content, nil
}

// walk 遍历规则进行爬取
func (c *Crawler) walk(task *store.Task, ruleIndex int, requestUrl, requestTitle string) {
	rule := task.Rules[ruleIndex]
	if ruleIndex >= len(task.Rules)-1 { // rule进行到最后一个，生成结果
		c.logger.Info("last rule", requestUrl)

		// 获取html内容
		content, err := c.request(requestUrl, rule)
		if err != nil {
			c.logger.Error("request failed", err)
			return
		}

		// 按照规则解析资源内容，得到解析结果列表
		ps := parser.FromRule(&rule, "")
		results, err := ps.Parse(content)
		if err != nil {
			c.logger.Error("walk parser.Parse", err)
			return
		}

		// 若url不完整，则处理
		baseUrl := util.GetBaseUrl(requestUrl)
		for i := 0; i < len(results); i++ {
			if results[i]["url"] != "" {
				if results[i]["url"][0] == '/' {
					results[i]["url"] = baseUrl + results[i]["url"]
				} else if results[i]["url"][0] == '.' {
					results[i]["url"] = requestUrl + "/" + results[i]["url"]
				}
			}
		}

		// 保存结果
		err = c.store.CreateCrawl(task.TaskId, requestTitle, requestUrl, results)
		if err != nil {
			c.logger.Error("walk store.AppendTaskResult", err)
			return
		}
	} else { // 中间rule，生成url列表传递给下一级rule
		c.logger.Info("intermediate rule", requestUrl)

		// http请求，获取资源内容
		content, err := c.httpFetcher.Get(requestUrl)
		if err != nil {
			c.logger.Error("walk fetcher.Get", err)
			return
		}

		// 根据规则解析资源内容，得到后续规则所需要的url列表
		ps := parser.FromRule(&task.Rules[ruleIndex], "")
		results, err := ps.Parse(content)
		if err != nil {
			c.logger.Error("walk parser.Parse", err)
			return
		}

		// 遍历本次解析得到的url列表，对每个url进行内容抓取并解析
		baseUrl := util.GetBaseUrl(requestUrl)

		var wg sync.WaitGroup
		wg.Add(len(results))
		// 并发爬取results地址列表
		doParallel(results, task.Rules[ruleIndex].Concurrent, func(row map[string]string) {
			defer wg.Done()

			path := row["url"]
			if path == "" {
				return
			}

			if path[0] == '/' {
				path = baseUrl + path
			} else if path[0] == '.' {
				path = requestUrl + "/" + path
			}

			c.walk(task, ruleIndex+1, path, row["title"])
		})
		wg.Wait()
	}
}

// doParallel 并发处理列表数据
func doParallel(data []map[string]string, concurrent int, f func(map[string]string)) {
	concurrentChan := make(chan struct{}, concurrent)

	for index := range data {
		concurrentChan <- struct{}{}
		go func(index int) {
			f(data[index])
			<-concurrentChan
		}(index)
	}
}

// GetTaskDetail 获取任务详情
func (c *Crawler) GetTaskDetail(taskId string) (*store.Task, error) {
	task, err := c.store.GetTask(taskId)
	if err != nil {
		c.logger.Error("GetTaskDetail", err)
		return nil, err
	}

	return task, nil
}

// Stopped 结束chan
func (c *Crawler) Stopped() chan struct{} {
	return c.stopChan
}

// Run 运行爬取服务
func (c *Crawler) Run(ctx context.Context) {
	c.logger.Info("Running Status", "Started")
	concurrentChan := make(chan struct{}, c.maxTaskConcurrent)

	// 起协程获取尚未开始的任务，加入待执行列表
	for {
		select {
		case <-ctx.Done(): // 手动停止服务
			close(concurrentChan)
			c.logger.Info("Running Status", "Stopped")
			c.stopChan <- struct{}{}
			return

		default: // 每隔2秒获取未开始的爬取任务
			tasks, err := c.store.ListUnStartedTasks(c.maxTaskConcurrent)
			c.logger.Info("ListUnStartedTasks", strconv.Itoa(len(tasks)))

			if err != nil {
				c.logger.Error("ListUnStartedTasks", err)
				time.Sleep(2 * time.Second)
			} else if len(tasks) == 0 { // 没有新任务，挂起2秒
				time.Sleep(2 * time.Second)
			} else { // 有新任务
				for idx := range tasks {
					concurrentChan <- struct{}{} // 并发控制：占位

					c.logger.Info("ExecNewTask", tasks[idx].TaskId)
					c.store.UpdateTask(tasks[idx].TaskId, store.TaskStatusStarted, 0) // 更新状态为开始爬取
					go func(t *store.Task) {
						err := c.ExecTask(t)
						if err != nil {
							//c.store.UpdateTaskStatus(t.TaskId, store.TaskStatusFailed) // 爬取失败
							c.logger.Error("TaskFailed:"+t.TaskId, err)
						}
						//c.store.UpdateTaskStatus(t.TaskId, store.TaskStatusSuccess) // 爬取成功
						<-concurrentChan // 并发控制：取消占位

						c.logger.Info("FinishTask", t.TaskId)
					}(tasks[idx])
				}
			}
		}
	}
}
