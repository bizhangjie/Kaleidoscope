package datetime

import "time"

var cstZone = time.FixedZone("GMT", 8*3600)

// Format 格式化时间格式为中国时区 2022-06-07 15:47:01
func Format(time time.Time) string {
	return time.In(cstZone).Format("2006-01-02 15:04:05")
}
