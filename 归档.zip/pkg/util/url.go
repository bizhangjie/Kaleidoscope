package util

import "net/url"

// getBaseUrl 获取基本url
func GetBaseUrl(fullUrl string) string {
	u, err := url.ParseRequestURI(fullUrl)
	if err != nil {
		return ""
	}

	return u.Scheme + "://" + u.Host
}
