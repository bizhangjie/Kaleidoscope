package util

import (
	"strconv"
	"unsafe"
)

// StringToBytes 字符串转字节数组（不分配内存,无须担心gc）
func StringToBytes(s string) []byte {
	return *(*[]byte)(unsafe.Pointer(
		&struct {
			string
			Cap int
		}{s, len(s)},
	))
}

// BytesToString 字符串转字节数组（不分配内存）
func BytesToString(bytes []byte) string {
	return *(*string)(unsafe.Pointer(&bytes))
}

// Int64ToString int64转字符串
func Int64ToString(num int64) string {
	return strconv.FormatInt(num, 10)
}

// StringToInt64 字符串转int64
func StringToInt64(str string) int64 {
	num, err := strconv.ParseInt(str, 10, 0)
	if err != nil {
		return 0
	}

	return num
}
