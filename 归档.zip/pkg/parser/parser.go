package parser

type Parser interface {
	Parse(content []byte) ([]map[string]string, error)
}

func FromRule(rule *Rule, proxy string) Parser {
	if rule == nil {
		return nil
	}

	switch rule.Type {
	case ParseTypeHTML, ParseTypeChrome:
		return &HTMLParser{
			rule:  rule,
			proxy: "",
		}
	case ParseTypeJSON:
		return &JSONParser{
			rule:  rule,
			proxy: "",
		}
	}

	return nil
}
