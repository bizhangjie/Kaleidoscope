package parser

import (
	"bytes"
	"strings"

	"github.com/PuerkitoBio/goquery"
)

type HTMLParser struct {
	rule  *Rule
	proxy string
}

// Parse 解析html文档
func (p *HTMLParser) Parse(content []byte) ([]map[string]string, error) {
	// html文档解析
	doc, err := goquery.NewDocumentFromReader(bytes.NewReader(content))
	if err != nil {
		return nil, err
	}

	results := make([]map[string]string, 0)

	if p.rule.ListSelector != "" { // 解析列表
		doc.Find(p.rule.ListSelector).Each(func(i int, selection *goquery.Selection) {
			result := p.findFields(selection)
			if result != nil {
				results = append(results, result)
			}
		})
	} else { // 解析对象
		result := p.findFields(doc.Selection)
		if result != nil {
			results = append(results, result)
		}
	}

	return results, nil
}

// findFields html文档中解析fields
func (p *HTMLParser) findFields(selection *goquery.Selection) map[string]string {
	result := make(map[string]string)

	// 遍历html rule，解析fields
	for _, field := range p.rule.Fields {
		var item *goquery.Selection
		if field.Selector == "" { // 取列表项本身
			item = selection
		} else {
			item = selection.Find(field.Selector).First()
			if item.Length() == 0 {
				return nil
			}
		}

		if field.Attr == "" {
			result[field.Name] = strings.Trim(item.Nodes[0].FirstChild.Data, " \n")
		} else {
			value, _ := item.Attr(field.Attr)
			value = strings.ReplaceAll(value, "&amp;", "&")
			if field.Template != "" {
				value = strings.Replace(field.Template, "{}", value, 1)
			}
			result[field.Name] = value
		}
	}

	return result
}
