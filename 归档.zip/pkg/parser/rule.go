package parser

type ParseType int

const (
	ParseTypeHTML   ParseType = iota // 0
	ParseTypeJSON                    // 1
	ParseTypeChrome                  // 2
)

type Field struct {
	Name     string `json:"name"`
	Selector string `json:"selector"`
	Attr     string `json:"attr"`
	Template string `json:"template"`
}

type Rule struct {
	Name         string    `json:"name"`
	Type         ParseType `json:"type"`
	RequestUrl   string    `json:"requestUrl"`
	ListSelector string    `json:"listSelector"`
	Concurrent   int       `json:"concurrent"`
	Fields       []Field   `json:"fields"`
}
