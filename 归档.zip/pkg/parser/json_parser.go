package parser

import (
	"github.com/tidwall/gjson"
	"strings"
)

type JSONParser struct {
	rule  *Rule
	proxy string
}

// Parse 解析json文档
func (p *JSONParser) Parse(content []byte) ([]map[string]string, error) {
	results := make([]map[string]string, 0)

	// 解析列表
	if p.rule.ListSelector != "" {
		list := gjson.GetBytes(content, p.rule.ListSelector)
		if !list.IsArray() && !list.IsObject() {
			return results, nil
		}

		list.ForEach(func(key, value gjson.Result) bool {
			if value.IsArray() {
				return true
			}

			var result map[string]string
			if value.IsObject() {
				result = p.findFields(value)
			} else {
				result = map[string]string{"content": value.String()}
			}

			if result == nil {
				return true
			}
			results = append(results, result)
			return true
		})

		return results, nil
	}

	// 解析对象
	result := p.findFields(gjson.ParseBytes(content))
	if result != nil {
		results = append(results, result)
	}

	return results, nil
}

// findFields 从json对象中解析 child
func (p *JSONParser) findFields(root gjson.Result) map[string]string {
	result := make(map[string]string)
	for _, field := range p.rule.Fields {
		item := root.Get(field.Selector)
		if item.IsArray() || item.IsObject() {
			continue
		}

		itemStr := item.String()
		if itemStr == "" {
			return nil
		}

		if field.Template != "" {
			itemStr = strings.Replace(field.Template, "{}", itemStr, 1)
		}

		result[field.Name] = itemStr
	}

	return result
}
