package logger

import (
	"log"
	"os"
)

type stdLogger struct {
	prefix string
	logger *log.Logger
}

func NewStdLogger(prefix string) *stdLogger {
	return &stdLogger{
		logger: log.New(os.Stdout, "", log.LstdFlags),
		prefix: prefix,
	}
}

func (l *stdLogger) Error(tag string, err error) {
	l.logger.Printf("[%s-error]%s:%v\n", l.prefix, tag, err)
}

func (l *stdLogger) Info(tag, info string) {
	l.logger.Printf("[%s-info]%s:%s\n", l.prefix, tag, info)
}
