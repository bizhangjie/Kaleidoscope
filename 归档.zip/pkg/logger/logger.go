package logger

type Logger interface {
	Error(tag string, err error)
	Info(tag, info string)
}
