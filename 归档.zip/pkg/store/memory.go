package store

import (
	"datasystem-discoverer/pkg/parser"
	"errors"
	"fmt"
	"sync"
	"time"

	"github.com/google/uuid"
)

type memory struct {
	taskMu   sync.RWMutex
	taskList map[string]*Task
}

func NewMemoryStore() *memory {
	return &memory{
		taskList: make(map[string]*Task),
	}
}

func (m *memory) CreateTask(rules []parser.Rule, status TaskStatus, cron string) (*Task, error) {
	now := time.Now()
	task := &Task{
		TaskId:    uuid.NewString(),
		Cron:      cron,
		Status:    status,
		Rules:     rules,
		CreatedAt: now,
		UpdatedAt: now,
	}

	m.taskMu.Lock()
	defer m.taskMu.Unlock()

	m.taskList[task.TaskId] = task

	return task, nil
}

func (m *memory) UpdateTask(taskId string, status TaskStatus, duration int) error {
	m.taskMu.Lock()
	defer m.taskMu.Unlock()

	m.taskList[taskId].Status = status

	return nil
}

func (m *memory) GetTask(taskId string) (*Task, error) {
	m.taskMu.RLock()
	defer m.taskMu.RUnlock()

	task, ok := m.taskList[taskId]
	if !ok {
		return nil, errors.New("task not found")
	}

	return task, nil
}

func (m *memory) ListUnStartedTasks(limit int) ([]*Task, error) {
	m.taskMu.RLock()
	defer m.taskMu.RUnlock()

	var tasks []*Task
	for key := range m.taskList {
		if len(tasks) >= limit {
			break
		}

		if m.taskList[key].Status == TaskStatusUnStart {
			tasks = append(tasks, m.taskList[key])
		}
	}

	return tasks, nil
}

func (m *memory) CreateCrawl(taskId string, title string, results []map[string]string) error {
	if len(results) == 0 {
		return nil
	}

	for _, r := range results {
		fmt.Println(r)
	}

	return nil
}
