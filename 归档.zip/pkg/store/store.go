package store

import (
	"datasystem-discoverer/pkg/parser"
	"time"
)

type TaskStatus int8

const (
	TaskStatusUnStart TaskStatus = iota
	TaskStatusStarted
	TaskStatusSuccess
	TaskStatusFailed
)

type Task struct {
	TaskId       string
	Cron         string
	Rules        []parser.Rule
	TotalCrawled int
	Duration     int
	Status       TaskStatus
	CreatedAt    time.Time
	UpdatedAt    time.Time
}

type Store interface {
	CreateTask(rules []parser.Rule, status TaskStatus, cron string) (*Task, error)
	UpdateTask(taskId string, status TaskStatus, duration int) error
	GetTask(taskId string) (*Task, error)
	ListUnStartedTasks(limit int) ([]*Task, error)
	CreateCrawl(taskId string, sourceTitle string, sourceUrl string, result []map[string]string) error
}
