package store

import (
	"context"
	"database/sql"
	"datasystem-discoverer/internal/citybrain"
	"datasystem-discoverer/internal/config"
	"datasystem-discoverer/internal/store/task"
	"datasystem-discoverer/pkg/parser"
	"datasystem-discoverer/pkg/util"
	"encoding/json"
	"log"

	_ "github.com/go-sql-driver/mysql"
)

type mysqlStore struct {
	workerId       string
	ctx            context.Context
	db             *sql.DB
	queries        *task.Queries
	addressCreator *citybrain.AddressCreator
}

func NewMysqlStore(ctx context.Context, cfg config.AppConfig) *mysqlStore {
	db, err := sql.Open("mysql", cfg.DbConnectionString)
	if err != nil {
		log.Println(err)
		return nil
	}

	return &mysqlStore{
		workerId:       cfg.WorkerID,
		ctx:            ctx,
		db:             db,
		queries:        task.New(db),
		addressCreator: citybrain.NewAddressCreator(cfg.Address),
	}
}

func jsonMarshal(rules []parser.Rule) string {
	data, err := json.Marshal(rules)
	if err != nil {
		log.Println(err)
		return ""
	}

	return util.BytesToString(data)
}

func jsonUnmarshal(data string, v interface{}) error {
	return json.Unmarshal(util.StringToBytes(data), v)
}

func (s *mysqlStore) CreateTask(rules []parser.Rule, status TaskStatus, cron string) (*Task, error) {
	taskId, err := s.queries.CreateTask(s.ctx, task.CreateTaskParams{
		Site:     rules[0].Name,
		RootUrl:  rules[0].RequestUrl,
		Status:   int32(status),
		Rule:     sql.NullString{String: jsonMarshal(rules), Valid: true},
		WorkerID: s.workerId,
		Remark:   "",
	})

	if err != nil {
		return nil, err
	}

	return &Task{TaskId: util.Int64ToString(taskId), Status: status, Rules: rules}, nil
}

func (s *mysqlStore) UpdateTask(taskId string, status TaskStatus, duration int) error {
	tId := util.StringToInt64(taskId)

	totalCrawled := 0
	// 任务完成时，统计抓取数量
	if status == TaskStatusSuccess {
		total, err := s.queries.GetTotalCrawled(s.ctx, tId)
		if err != nil {
			return err
		}

		totalCrawled = int(total)
	}

	_, err := s.queries.UpdateTask(s.ctx, task.UpdateTaskParams{
		Status:       int32(status),
		TotalCrawled: int32(totalCrawled),
		Duration:     int32(duration),
		ID:           tId,
	})
	return err
}

func dbTaskToTask(dbTask *task.Task) *Task {
	var rules []parser.Rule
	err := jsonUnmarshal(dbTask.Rule.String, &rules)
	if err != nil {
		return nil
	}
	return &Task{
		TaskId:    util.Int64ToString(dbTask.ID),
		Cron:      "",
		Rules:     rules,
		Status:    TaskStatus(dbTask.Status),
		CreatedAt: dbTask.UpdatedAt,
		UpdatedAt: dbTask.UpdatedAt,
	}
}

func (s *mysqlStore) GetTask(taskId string) (*Task, error) {
	t, err := s.queries.GetTask(s.ctx, util.StringToInt64(taskId))
	if err != nil {
		return nil, err
	}

	return dbTaskToTask(&t), nil
}

func (s *mysqlStore) ListUnStartedTasks(limit int) ([]*Task, error) {
	taskList, err := s.queries.ListUnStartedTasks(s.ctx, task.ListUnStartedTasksParams{WorkerID: s.workerId, Limit: int32(limit)})
	if err != nil {
		return nil, err
	}

	tasks := make([]*Task, 0)
	for idx := range taskList {
		tasks = append(tasks, dbTaskToTask(&taskList[idx]))
	}

	return tasks, nil
}

func (s *mysqlStore) CreateCrawl(taskId string, sourceTitle string, sourceUrl string, result []map[string]string) error {
	log.Printf("[Store-info]CreateDpAddress: %s", taskId)
	for _, r := range result {
		dpAddress, err := s.addressCreator.Create(r["title"], sourceTitle, r["url"], sourceTitle, sourceUrl, 2)
		if err != nil {
			log.Printf("[Store-info]Create dpAddress failed: %v", err)
			continue
		}

		log.Printf("[Store-info]CreateDpAddress: %s, %s", taskId, dpAddress)

		_, err = s.queries.CreateCrawl(s.ctx, task.CreateCrawlParams{
			TaskID: util.StringToInt64(taskId),
			Title:  r["title"],
			Link:   r["url"],
			Udl:    dpAddress,
			Remark: sourceTitle + sourceUrl,
		})

		if err != nil {
			log.Printf("CreateCrawl failed: %s, %v", taskId, err)
		}
	}

	return nil
}
