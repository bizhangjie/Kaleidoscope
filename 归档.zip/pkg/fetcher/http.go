package fetcher

import (
	"io"
	"net/http"
	"time"
)

type HttpFetcher struct {
	client *http.Client
	proxy  string
}

func NewHttpFetcher(readTimeout time.Duration, proxy string) HttpFetcher {
	trans := http.Transport{
		Proxy:                 nil,
		MaxIdleConns:          0,
		MaxIdleConnsPerHost:   0,
		MaxConnsPerHost:       0,
		IdleConnTimeout:       0,
		ResponseHeaderTimeout: 0,
	}

	return HttpFetcher{
		client: &http.Client{
			Transport: &trans,
			Timeout:   readTimeout,
		},
		proxy: "",
	}
}

func (h HttpFetcher) Get(url string) ([]byte, error) {
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("User-Agent", userAgent)
	resp, err := h.client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	return data, nil
}
