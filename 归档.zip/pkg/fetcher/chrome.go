package fetcher

import (
	"context"
	"datasystem-discoverer/pkg/parser"
	"github.com/chromedp/chromedp"
	"log"
	"time"
)

const userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.61 Safari/537.36"

type ChromeFetcher struct {
	requestTimeout time.Duration
	chromeCtx      context.Context
}

// NewChromeFetcher 初始化chrome上下文，chromeUrl为空则启动本地chrome程序，否则连接远程chrome调试地址
// 容器内跑crawler时需要注意与headless-chrome远程地址的网络互通问题
// docker-compose模式可使用ws://servicename:9222/，容器内访问host的chrome端口需要设置--add-host host.docker.internal:host-gateway
func NewChromeFetcher(chromeUrl string, enableLog bool, requestTimeout time.Duration) ChromeFetcher {
	var c context.Context
	if chromeUrl == "" { // 启动本地chrome程序
		options := append(chromedp.DefaultExecAllocatorOptions[:],
			chromedp.Flag("blink-settings", "imagesEnabled=false"),
			chromedp.UserAgent(userAgent),
			chromedp.NoFirstRun,
			chromedp.DisableGPU,
			chromedp.Headless,
			chromedp.NoSandbox,
			chromedp.NoDefaultBrowserCheck,
		)

		c, _ = chromedp.NewExecAllocator(context.Background(), options...)
	} else { // 远程连接chrome调试地址
		c, _ = chromedp.NewRemoteAllocator(context.Background(), chromeUrl)
	}

	var chromeCtx context.Context
	if enableLog {
		chromeCtx, _ = chromedp.NewContext(c, chromedp.WithLogf(log.Printf))
	} else {
		chromeCtx, _ = chromedp.NewContext(c)
	}

	chromedp.Run(chromeCtx, chromedp.Tasks{})

	return ChromeFetcher{
		chromeCtx:      chromeCtx,
		requestTimeout: requestTimeout,
	}
}

func (f ChromeFetcher) PaginateFetch(requestUrl string, rule parser.Rule) (string, error) {
	tasks := chromedp.Tasks{
		chromedp.Navigate(requestUrl),
		chromedp.WaitReady(rule.ListSelector+" "+rule.Fields[0].Selector, chromedp.ByQuery),
	}

	var html string
	tasks = append(tasks, chromedp.OuterHTML("body", &html, chromedp.ByQuery))

	ctx, cancel := context.WithTimeout(f.chromeCtx, f.requestTimeout)
	defer cancel()

	err := chromedp.Run(ctx, tasks)
	return html, err
}
