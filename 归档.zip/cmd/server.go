package main

import (
	"context"
	"datasystem-discoverer/internal/config"
	"datasystem-discoverer/internal/crawler"
	mux "datasystem-discoverer/internal/http"
	"fmt"
	"log"
	"net/http"
	"os/signal"
	"syscall"
	"time"
)

func main() {
	log.Println("register os signal")
	// 注册系统信号
	signalContext, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()
	log.Println("os signal registered")

	// 启动crawler服务
	appConfig := config.FromFile() // 本地测试用
	// appConfig := config.FromEnv()
	log.Printf("config: %v\n", appConfig)

	cr := crawler.New(appConfig)
	go cr.Run(signalContext)

	// 启动http服务
	router := mux.InitRouter(cr)
	server := http.Server{
		Addr:    appConfig.HTTPListenAt,
		Handler: router,
	}
	go func() {
		<-signalContext.Done()

		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()

		err := server.Shutdown(ctx)
		if err != nil {
			fmt.Println(err)
		}
		log.Println("[HTTP-info]Running Status:Stopped")
	}()
	log.Printf("[HTTP-info]Running Status:Started, Listen at: %s", appConfig.HTTPListenAt)
	err := server.ListenAndServe()
	if err != nil && err != http.ErrServerClosed {
		panic(err)
	}

	<-cr.Stopped()
}
